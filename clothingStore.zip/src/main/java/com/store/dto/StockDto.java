package com.store.dto;

import lombok.Data;

@Data
public class StockDto {
	private int pd_id;
	private String pd_size;
	private int pd_stock;
}
