package com.store.service;

public class OrderServiceImpl implements OrderService {

}
