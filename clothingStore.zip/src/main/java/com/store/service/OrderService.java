package com.store.service;

public interface OrderService {
	
}
